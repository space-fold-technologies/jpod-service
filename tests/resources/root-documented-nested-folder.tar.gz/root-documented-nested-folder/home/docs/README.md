Peeling layers of lies like onions
