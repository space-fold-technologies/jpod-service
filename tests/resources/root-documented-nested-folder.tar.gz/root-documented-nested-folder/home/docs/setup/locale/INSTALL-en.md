Here we tell lies about installing software
