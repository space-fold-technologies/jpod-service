The lies start here
